n1 = int(input("Insira o primeiro número: "))
n2 = int(input("Insira o segundo número: "))

if n1 == n2:
    print("Os números são iguais.")
else: print("Os números são diferentes.")