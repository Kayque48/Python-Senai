n1 = int(input("Digite o valor do primeiro número: "))
n2 = int(input("Digite o valor do segundo número: "))

if n1 < n2:
    print("O maior valor é " , n2 , "\nO menor valor é " , n1)
else:
    print("O maior valor é " , n1 , "\nO menor valor é " , n2)