n1 = float(input("Inserir primeira nota: "))
n2 = float(input("Inserir segunda nota: "))

media= (n1 + n2) / 2

if media > 5:
    print("Aprovado!")
else : print("Reprovado!")